@echo off
:: ─────────────────────────────────────────────────────────────
::  Hospital Management System - Build & Run (Windows)
:: ─────────────────────────────────────────────────────────────
setlocal
set SRC_DIR=%~dp0src
set OUT_DIR=%~dp0out
set JAR=%~dp0lib\mysql-connector-j-8.0.33.jar

:: Compile
echo Compiling...
if not exist "%OUT_DIR%" mkdir "%OUT_DIR%"
for /r "%SRC_DIR%" %%f in (*.java) do set FILES=%%f %FILES%
javac -cp "%JAR%" -d "%OUT_DIR%" %FILES%
if errorlevel 1 (echo Compilation FAILED & pause & exit /b 1)
echo Compiled successfully.

:: Run
java -cp "%OUT_DIR%;%JAR%" com.hospital.ui.MainMenu
pause
