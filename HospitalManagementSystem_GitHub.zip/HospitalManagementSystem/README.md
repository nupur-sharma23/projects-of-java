# 🏥 Hospital Management System

![Java](https://img.shields.io/badge/Java-17%2B-orange?logo=openjdk)
![JDBC](https://img.shields.io/badge/JDBC-MySQL-blue?logo=mysql)
![License](https://img.shields.io/badge/License-MIT-green)
![Platform](https://img.shields.io/badge/Platform-Windows%20%7C%20Linux%20%7C%20Mac-lightgrey)

A fully functional **console-based Hospital Management System** built with pure Java and JDBC (MySQL). No frameworks — just clean Java, raw SQL, and the DAO pattern.

---

## 📋 Table of Contents

- [Features](#-features)
- [Project Structure](#-project-structure)
- [Tech Stack](#-tech-stack)
- [Prerequisites](#-prerequisites)
- [Setup & Installation](#-setup--installation)
- [Database Schema](#-database-schema)
- [How to Use](#-how-to-use)
- [Design Patterns](#-design-patterns)
- [Sample Data](#-sample-data-auto-seeded)
- [Contributing](#-contributing)
- [License](#-license)

---

## ✨ Features

| Module | Capabilities |
|---|---|
| 🧑‍⚕️ **Patients** | Register, view all, search by name/phone/blood group, update, delete |
| 👨‍⚕️ **Doctors** | Add doctors, toggle availability, filter by specialization |
| 📅 **Appointments** | Book, view by date/patient, mark complete, cancel |
| 🛏️ **Rooms** | Add rooms, view available, update status (Available/Occupied/Maintenance) |
| 🏠 **Admissions** | Admit patient with room allocation, discharge with auto-billing |
| 💊 **Pharmacy** | Add medicines, update stock, low-stock alerts, expiry tracking |
| 💳 **Billing** | Auto bill on discharge, manual bills, payment processing, pending dues |
| 📊 **Reports** | Live dashboard, today's appointments, current admissions, pending bills |

---

## 📁 Project Structure

```
HospitalManagementSystem/
│
├── src/
│   └── com/hospital/
│       ├── model/                  # Plain Java objects (POJOs)
│       │   ├── Patient.java
│       │   ├── Doctor.java
│       │   ├── Appointment.java
│       │   ├── Room.java
│       │   ├── Admission.java
│       │   ├── Medicine.java
│       │   └── Bill.java
│       │
│       ├── dao/                    # Database access (all JDBC here)
│       │   ├── PatientDAO.java
│       │   ├── DoctorDAO.java
│       │   ├── AppointmentDAO.java
│       │   ├── RoomDAO.java
│       │   ├── AdmissionDAO.java
│       │   ├── MedicineDAO.java
│       │   └── BillDAO.java
│       │
│       ├── util/                   # Helpers
│       │   ├── DBConnection.java   # Singleton JDBC connection
│       │   └── DatabaseSetup.java  # Auto-creates tables + seeds data
│       │
│       └── ui/
│           └── MainMenu.java       # All console menus & entry point
│
├── lib/                            # Place mysql-connector-j jar here
├── run.sh                          # Build & run (Linux/Mac)
├── run.bat                         # Build & run (Windows)
└── README.md
```

---

## 🛠 Tech Stack

- **Language**: Java 17+
- **Database**: MySQL 8.0+
- **Connectivity**: JDBC (`mysql-connector-j`)
- **Pattern**: DAO (Data Access Object)
- **Build**: Plain `javac` — no Maven/Gradle needed

---

## ✅ Prerequisites

| Tool | Version | Download |
|---|---|---|
| Java JDK | 17 or higher | https://adoptium.net |
| MySQL | 8.0 or higher | https://dev.mysql.com/downloads/ |
| MySQL Connector/J | 8.0.33 | https://repo1.maven.org/maven2/com/mysql/mysql-connector-j/8.0.33/mysql-connector-j-8.0.33.jar |

---

## 🚀 Setup & Installation

### Step 1 — Clone the repository

```bash
git clone https://github.com/your-username/HospitalManagementSystem.git
cd HospitalManagementSystem
```

### Step 2 — Add the JDBC driver

Download `mysql-connector-j-8.0.33.jar` and place it in the `lib/` folder:

```bash
mkdir lib
curl -L https://repo1.maven.org/maven2/com/mysql/mysql-connector-j/8.0.33/mysql-connector-j-8.0.33.jar \
     -o lib/mysql-connector-j-8.0.33.jar
```

### Step 3 — Configure database credentials

Edit `src/com/hospital/util/DBConnection.java`:

```java
private static final String URL      = "jdbc:mysql://localhost:3306/hospital_db?useSSL=false&serverTimezone=UTC";
private static final String USER     = "root";          // ← your MySQL username
private static final String PASSWORD = "your_password"; // ← your MySQL password
```

### Step 4 — Create the database

Log into MySQL and run:

```sql
CREATE DATABASE hospital_db;
```

> All tables are created automatically on the first run. No manual SQL needed.

### Step 5 — Build and run

**Linux / Mac:**
```bash
chmod +x run.sh
./run.sh
```

**Windows:**
```
run.bat
```

**Or compile and run manually:**
```bash
# Compile
javac -cp lib/mysql-connector-j-8.0.33.jar -d out $(find src -name "*.java")

# Run (Linux/Mac)
java -cp "out:lib/mysql-connector-j-8.0.33.jar" com.hospital.ui.MainMenu

# Run (Windows)
java -cp "out;lib/mysql-connector-j-8.0.33.jar" com.hospital.ui.MainMenu
```

---

## 🗄 Database Schema

```
┌─────────────┐     ┌──────────────┐     ┌───────────────┐
│  patients   │────<│ appointments │>────│   doctors     │
│─────────────│     │──────────────│     │───────────────│
│ patient_id  │     │appointment_id│     │ doctor_id     │
│ name        │     │ patient_id   │     │ name          │
│ age         │     │ doctor_id    │     │ specialization│
│ gender      │     │ date / time  │     │ phone / email │
│ phone       │     │ status       │     │ available     │
│ blood_group │     └──────────────┘     └───────────────┘
└──────┬──────┘
       │           ┌──────────────┐     ┌───────────────┐
       └──────────<│  admissions  │>────│    rooms      │
                   │──────────────│     │───────────────│
                   │ admission_id │     │ room_id       │
                   │ patient_id   │     │ room_number   │
                   │ room_id      │     │ room_type     │
                   │ doctor_id    │     │ status        │
                   │ admission_dt │     │ price_per_day │
                   │ discharge_dt │     └───────────────┘
                   └──────────────┘

┌─────────────┐     ┌───────────────┐
│  medicines  │────<│ prescriptions │
│─────────────│     │───────────────│
│ medicine_id │     │prescription_id│
│ name        │     │appointment_id │
│ quantity    │     │ medicine_id   │
│ price       │     │ dosage        │
│ expiry_date │     └───────────────┘
└─────────────┘

┌──────────────┐
│    bills     │
│──────────────│
│ bill_id      │
│ patient_id   │
│ admission_id │
│ total_amount │
│ paid_amount  │
│ status       │
└──────────────┘
```

**8 tables** with full foreign key constraints and `ON DELETE CASCADE`.

---

## 💻 How to Use

After launching, you'll see the main menu:

```
╔══════════════════════════════╗
║         MAIN MENU            ║
╠══════════════════════════════╣
║  1. Patient Management       ║
║  2. Doctor Management        ║
║  3. Appointments             ║
║  4. Room Management          ║
║  5. Admissions               ║
║  6. Medicine / Pharmacy      ║
║  7. Billing                  ║
║  8. Reports & Dashboard      ║
║  0. Exit                     ║
╚══════════════════════════════╝
```

**Typical workflow:**
1. Register a **Patient** (Menu 1 → 1)
2. View available **Doctors** (Menu 2 → 3)
3. Book an **Appointment** (Menu 3 → 1)
4. **Admit** the patient to a room (Menu 5 → 1)
5. **Discharge** the patient — bill is auto-generated (Menu 5 → 4)
6. Process **Payment** (Menu 7 → 3)

---

## 🏗 Design Patterns

| Pattern | Where used | Why |
|---|---|---|
| **DAO** | All `*DAO.java` classes | Separates SQL from business logic |
| **Singleton** | `DBConnection.java` | One shared DB connection |
| **Transaction** | `AdmissionDAO` admit/discharge | Keeps room status and admission record in sync atomically |
| **Layered Architecture** | model → dao → ui | Clear separation of concerns |

---

## 🌱 Sample Data (auto-seeded)

On first run, the following seed data is inserted:

**Doctors**
| Name | Specialization |
|---|---|
| Dr. Anil Sharma | Cardiologist |
| Dr. Priya Mehta | Neurologist |
| Dr. Rajan Patel | Orthopedician |
| Dr. Sunita Gupta | Pediatrician |
| Dr. Vikas Kumar | General Surgery |

**Rooms**: 2 General (₹800/day), 2 Private (₹2000/day), 1 ICU (₹5000/day), 1 Emergency (₹3000/day)

**Medicines**: Paracetamol, Amoxicillin, Metformin, Atorvastatin, Omeprazole

---

## 🤝 Contributing

Contributions are welcome!

1. Fork the repository
2. Create a feature branch: `git checkout -b feature/your-feature`
3. Commit your changes: `git commit -m "Add your feature"`
4. Push to the branch: `git push origin feature/your-feature`
5. Open a Pull Request

**Ideas for improvement:**
- Add a GUI using JavaFX or Swing
- Add user authentication (admin/doctor/receptionist roles)
- Export reports to PDF or Excel
- Add Maven/Gradle build support
- Add JUnit tests for DAO layer

---

## 📄 License

This project is licensed under the **MIT License** — see the [LICENSE](LICENSE) file for details.

---

## 👨‍💻 Author

Made with ☕ and Java.  
Feel free to ⭐ star this repo if you found it helpful!
