package com.hospital.dao;

import com.hospital.model.Bill;
import com.hospital.util.DBConnection;

import java.math.BigDecimal;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class BillDAO {

    public boolean generateBill(Bill bill) {
        String sql = """
            INSERT INTO bills (patient_id, admission_id, total_amount, paid_amount, payment_status, bill_date)
            VALUES (?,?,?,?,?,?)
            """;
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, bill.getPatientId());
            if (bill.getAdmissionId() != null) ps.setInt(2, bill.getAdmissionId()); else ps.setNull(2, Types.INTEGER);
            ps.setBigDecimal(3, bill.getTotalAmount());
            ps.setBigDecimal(4, bill.getPaidAmount());
            ps.setString(5, bill.getPaymentStatus());
            ps.setDate(6, Date.valueOf(bill.getBillDate()));
            int rows = ps.executeUpdate();
            if (rows > 0) {
                ResultSet keys = ps.getGeneratedKeys();
                if (keys.next()) bill.setBillId(keys.getInt(1));
                return true;
            }
        } catch (SQLException e) {
            System.err.println("Error generating bill: " + e.getMessage());
        }
        return false;
    }

    public boolean makePayment(int billId, BigDecimal amount) {
        String sql = """
            UPDATE bills
            SET paid_amount = paid_amount + ?,
                payment_status = CASE
                    WHEN paid_amount + ? >= total_amount THEN 'PAID'
                    WHEN paid_amount + ? > 0 THEN 'PARTIAL'
                    ELSE 'PENDING'
                END
            WHERE bill_id=?
            """;
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setBigDecimal(1, amount);
            ps.setBigDecimal(2, amount);
            ps.setBigDecimal(3, amount);
            ps.setInt(4, billId);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error processing payment: " + e.getMessage());
        }
        return false;
    }

    public List<Bill> getAllBills() {
        List<Bill> list = new ArrayList<>();
        String sql = """
            SELECT b.*, p.name AS patient_name
            FROM bills b
            JOIN patients p ON b.patient_id = p.patient_id
            ORDER BY b.bill_date DESC
            """;
        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) list.add(mapBill(rs));
        } catch (SQLException e) {
            System.err.println("Error fetching bills: " + e.getMessage());
        }
        return list;
    }

    public List<Bill> getPendingBills() {
        List<Bill> list = new ArrayList<>();
        String sql = """
            SELECT b.*, p.name AS patient_name
            FROM bills b
            JOIN patients p ON b.patient_id = p.patient_id
            WHERE b.payment_status IN ('PENDING','PARTIAL')
            ORDER BY b.bill_date
            """;
        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) list.add(mapBill(rs));
        } catch (SQLException e) {
            System.err.println("Error fetching pending bills: " + e.getMessage());
        }
        return list;
    }

    public Bill getBillById(int billId) {
        String sql = "SELECT b.*, p.name AS patient_name FROM bills b JOIN patients p ON b.patient_id=p.patient_id WHERE b.bill_id=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, billId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return mapBill(rs);
        } catch (SQLException e) {
            System.err.println("Error fetching bill: " + e.getMessage());
        }
        return null;
    }

    private Bill mapBill(ResultSet rs) throws SQLException {
        Bill b = new Bill();
        b.setBillId(rs.getInt("bill_id"));
        b.setPatientId(rs.getInt("patient_id"));
        int admId = rs.getInt("admission_id");
        if (!rs.wasNull()) b.setAdmissionId(admId);
        b.setTotalAmount(rs.getBigDecimal("total_amount"));
        b.setPaidAmount(rs.getBigDecimal("paid_amount"));
        b.setPaymentStatus(rs.getString("payment_status"));
        b.setBillDate(rs.getDate("bill_date").toLocalDate());
        b.setPatientName(rs.getString("patient_name"));
        return b;
    }
}
