package com.hospital.dao;

import com.hospital.model.Medicine;
import com.hospital.util.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class MedicineDAO {

    public boolean addMedicine(Medicine medicine) {
        String sql = "INSERT INTO medicines (name, manufacturer, quantity, price, expiry_date) VALUES (?,?,?,?,?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, medicine.getName());
            ps.setString(2, medicine.getManufacturer());
            ps.setInt(3, medicine.getQuantity());
            ps.setBigDecimal(4, medicine.getPrice());
            ps.setDate(5, Date.valueOf(medicine.getExpiryDate()));
            int rows = ps.executeUpdate();
            if (rows > 0) {
                ResultSet keys = ps.getGeneratedKeys();
                if (keys.next()) medicine.setMedicineId(keys.getInt(1));
                return true;
            }
        } catch (SQLException e) {
            System.err.println("Error adding medicine: " + e.getMessage());
        }
        return false;
    }

    public boolean updateStock(int medicineId, int newQuantity) {
        String sql = "UPDATE medicines SET quantity=? WHERE medicine_id=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, newQuantity);
            ps.setInt(2, medicineId);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error updating stock: " + e.getMessage());
        }
        return false;
    }

    public boolean deleteMedicine(int medicineId) {
        String sql = "DELETE FROM medicines WHERE medicine_id=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, medicineId);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error deleting medicine: " + e.getMessage());
        }
        return false;
    }

    public List<Medicine> getAllMedicines() {
        List<Medicine> list = new ArrayList<>();
        String sql = "SELECT * FROM medicines ORDER BY name";
        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) list.add(mapMedicine(rs));
        } catch (SQLException e) {
            System.err.println("Error fetching medicines: " + e.getMessage());
        }
        return list;
    }

    public List<Medicine> getLowStockMedicines(int threshold) {
        List<Medicine> list = new ArrayList<>();
        String sql = "SELECT * FROM medicines WHERE quantity <= ? ORDER BY quantity";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, threshold);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) list.add(mapMedicine(rs));
        } catch (SQLException e) {
            System.err.println("Error fetching low-stock medicines: " + e.getMessage());
        }
        return list;
    }

    public List<Medicine> searchMedicines(String keyword) {
        List<Medicine> list = new ArrayList<>();
        String sql = "SELECT * FROM medicines WHERE name LIKE ? OR manufacturer LIKE ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            String kw = "%" + keyword + "%";
            ps.setString(1, kw);
            ps.setString(2, kw);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) list.add(mapMedicine(rs));
        } catch (SQLException e) {
            System.err.println("Error searching medicines: " + e.getMessage());
        }
        return list;
    }

    private Medicine mapMedicine(ResultSet rs) throws SQLException {
        Medicine m = new Medicine();
        m.setMedicineId(rs.getInt("medicine_id"));
        m.setName(rs.getString("name"));
        m.setManufacturer(rs.getString("manufacturer"));
        m.setQuantity(rs.getInt("quantity"));
        m.setPrice(rs.getBigDecimal("price"));
        m.setExpiryDate(rs.getDate("expiry_date").toLocalDate());
        return m;
    }
}
