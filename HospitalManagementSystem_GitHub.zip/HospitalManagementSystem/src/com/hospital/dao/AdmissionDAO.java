package com.hospital.dao;

import com.hospital.model.Admission;
import com.hospital.util.DBConnection;

import java.math.BigDecimal;
import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class AdmissionDAO {

    public boolean admitPatient(Admission admission) {
        String sql = """
            INSERT INTO admissions (patient_id, room_id, doctor_id, admission_date, diagnosis, status)
            VALUES (?,?,?,?,?,?)
            """;
        try (Connection conn = DBConnection.getConnection()) {
            conn.setAutoCommit(false);
            try (PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
                ps.setInt(1, admission.getPatientId());
                ps.setInt(2, admission.getRoomId());
                ps.setInt(3, admission.getDoctorId());
                ps.setDate(4, Date.valueOf(admission.getAdmissionDate()));
                ps.setString(5, admission.getDiagnosis());
                ps.setString(6, "ADMITTED");

                ps.executeUpdate();
                ResultSet keys = ps.getGeneratedKeys();
                if (keys.next()) admission.setAdmissionId(keys.getInt(1));

                // Mark room as occupied
                String roomSql = "UPDATE rooms SET status='OCCUPIED' WHERE room_id=?";
                try (PreparedStatement rps = conn.prepareStatement(roomSql)) {
                    rps.setInt(1, admission.getRoomId());
                    rps.executeUpdate();
                }

                conn.commit();
                return true;
            } catch (SQLException ex) {
                conn.rollback();
                throw ex;
            }
        } catch (SQLException e) {
            System.err.println("Error admitting patient: " + e.getMessage());
        }
        return false;
    }

    public boolean dischargePatient(int admissionId, LocalDate dischargeDate, BigDecimal totalBill) {
        String sql = "UPDATE admissions SET discharge_date=?, total_bill=?, status='DISCHARGED' WHERE admission_id=?";
        try (Connection conn = DBConnection.getConnection()) {
            conn.setAutoCommit(false);
            try {
                // Get room_id first
                String getRoomSql = "SELECT room_id FROM admissions WHERE admission_id=?";
                int roomId = -1;
                try (PreparedStatement ps = conn.prepareStatement(getRoomSql)) {
                    ps.setInt(1, admissionId);
                    ResultSet rs = ps.executeQuery();
                    if (rs.next()) roomId = rs.getInt("room_id");
                }

                try (PreparedStatement ps = conn.prepareStatement(sql)) {
                    ps.setDate(1, Date.valueOf(dischargeDate));
                    ps.setBigDecimal(2, totalBill);
                    ps.setInt(3, admissionId);
                    ps.executeUpdate();
                }

                // Free the room
                if (roomId > 0) {
                    String roomSql = "UPDATE rooms SET status='AVAILABLE' WHERE room_id=?";
                    try (PreparedStatement ps = conn.prepareStatement(roomSql)) {
                        ps.setInt(1, roomId);
                        ps.executeUpdate();
                    }
                }

                conn.commit();
                return true;
            } catch (SQLException ex) {
                conn.rollback();
                throw ex;
            }
        } catch (SQLException e) {
            System.err.println("Error discharging patient: " + e.getMessage());
        }
        return false;
    }

    public List<Admission> getAllAdmissions() {
        List<Admission> list = new ArrayList<>();
        String sql = """
            SELECT a.*, p.name AS patient_name, r.room_number, d.name AS doctor_name
            FROM admissions a
            JOIN patients p ON a.patient_id = p.patient_id
            JOIN rooms    r ON a.room_id    = r.room_id
            JOIN doctors  d ON a.doctor_id  = d.doctor_id
            ORDER BY a.admission_date DESC
            """;
        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) list.add(mapAdmission(rs));
        } catch (SQLException e) {
            System.err.println("Error fetching admissions: " + e.getMessage());
        }
        return list;
    }

    public List<Admission> getCurrentAdmissions() {
        List<Admission> list = new ArrayList<>();
        String sql = """
            SELECT a.*, p.name AS patient_name, r.room_number, d.name AS doctor_name
            FROM admissions a
            JOIN patients p ON a.patient_id = p.patient_id
            JOIN rooms    r ON a.room_id    = r.room_id
            JOIN doctors  d ON a.doctor_id  = d.doctor_id
            WHERE a.status='ADMITTED'
            ORDER BY a.admission_date DESC
            """;
        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) list.add(mapAdmission(rs));
        } catch (SQLException e) {
            System.err.println("Error fetching admissions: " + e.getMessage());
        }
        return list;
    }

    public Admission getAdmissionById(int admissionId) {
        String sql = """
            SELECT a.*, p.name AS patient_name, r.room_number, d.name AS doctor_name
            FROM admissions a
            JOIN patients p ON a.patient_id = p.patient_id
            JOIN rooms    r ON a.room_id    = r.room_id
            JOIN doctors  d ON a.doctor_id  = d.doctor_id
            WHERE a.admission_id=?
            """;
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, admissionId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return mapAdmission(rs);
        } catch (SQLException e) {
            System.err.println("Error fetching admission: " + e.getMessage());
        }
        return null;
    }

    private Admission mapAdmission(ResultSet rs) throws SQLException {
        Admission a = new Admission();
        a.setAdmissionId(rs.getInt("admission_id"));
        a.setPatientId(rs.getInt("patient_id"));
        a.setRoomId(rs.getInt("room_id"));
        a.setDoctorId(rs.getInt("doctor_id"));
        a.setAdmissionDate(rs.getDate("admission_date").toLocalDate());
        Date dd = rs.getDate("discharge_date");
        if (dd != null) a.setDischargeDate(dd.toLocalDate());
        a.setDiagnosis(rs.getString("diagnosis"));
        a.setTotalBill(rs.getBigDecimal("total_bill"));
        a.setStatus(rs.getString("status"));
        a.setPatientName(rs.getString("patient_name"));
        a.setRoomNumber(rs.getString("room_number"));
        a.setDoctorName(rs.getString("doctor_name"));
        return a;
    }
}
