package com.hospital.ui;

import com.hospital.dao.*;
import com.hospital.model.*;
import com.hospital.util.DBConnection;
import com.hospital.util.DatabaseSetup;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;
import java.util.Scanner;

public class MainMenu {

    private static final Scanner sc = new Scanner(System.in);
    private static final PatientDAO     patientDAO     = new PatientDAO();
    private static final DoctorDAO      doctorDAO      = new DoctorDAO();
    private static final AppointmentDAO appointmentDAO = new AppointmentDAO();
    private static final RoomDAO        roomDAO        = new RoomDAO();
    private static final AdmissionDAO   admissionDAO   = new AdmissionDAO();
    private static final MedicineDAO    medicineDAO    = new MedicineDAO();
    private static final BillDAO        billDAO        = new BillDAO();

    // ─────────────────────── ENTRY POINT ───────────────────────
    public static void main(String[] args) {
        System.out.println("Initialising database...");
        DatabaseSetup.initializeDatabase();
        printBanner();

        boolean running = true;
        while (running) {
            printMainMenu();
            int choice = readInt("Enter choice: ");
            switch (choice) {
                case 1  -> patientMenu();
                case 2  -> doctorMenu();
                case 3  -> appointmentMenu();
                case 4  -> roomMenu();
                case 5  -> admissionMenu();
                case 6  -> medicineMenu();
                case 7  -> billingMenu();
                case 8  -> reportsMenu();
                case 0  -> { running = false; System.out.println("\nGoodbye! Stay healthy 🏥"); }
                default -> System.out.println("  Invalid option.");
            }
        }
        DBConnection.closeConnection();
    }

    // ─────────────────────── PATIENTS ───────────────────────
    private static void patientMenu() {
        while (true) {
            printSectionHeader("PATIENT MANAGEMENT");
            System.out.println("  1. Register New Patient");
            System.out.println("  2. View All Patients");
            System.out.println("  3. Search Patients");
            System.out.println("  4. Update Patient");
            System.out.println("  5. Delete Patient");
            System.out.println("  0. Back");
            int ch = readInt("Choice: ");
            switch (ch) {
                case 1 -> registerPatient();
                case 2 -> listPatients();
                case 3 -> searchPatients();
                case 4 -> updatePatient();
                case 5 -> deletePatient();
                case 0 -> { return; }
                default -> System.out.println("  Invalid option.");
            }
        }
    }

    private static void registerPatient() {
        System.out.println("\n--- Register New Patient ---");
        Patient p = new Patient();
        System.out.print("Name        : "); p.setName(sc.nextLine().trim());
        p.setAge(readInt("Age         : "));
        System.out.print("Gender (M/F): "); p.setGender(sc.nextLine().trim());
        System.out.print("Phone       : "); p.setPhone(sc.nextLine().trim());
        System.out.print("Address     : "); p.setAddress(sc.nextLine().trim());
        System.out.print("Blood Group : "); p.setBloodGroup(sc.nextLine().trim());

        if (patientDAO.addPatient(p))
            System.out.printf("  ✓ Patient registered. ID = %d%n", p.getPatientId());
        else
            System.out.println("  ✗ Registration failed.");
    }

    private static void listPatients() {
        List<Patient> list = patientDAO.getAllPatients();
        printTable("ALL PATIENTS (" + list.size() + ")",
                "ID    | Name                      | Age | Gender | Phone        | Blood",
                list);
    }

    private static void searchPatients() {
        System.out.print("Search (name/phone/blood): ");
        String kw = sc.nextLine().trim();
        List<Patient> list = patientDAO.searchPatients(kw);
        printTable("SEARCH RESULTS", "ID    | Name                      | Age | Gender | Phone        | Blood", list);
    }

    private static void updatePatient() {
        int id = readInt("Patient ID to update: ");
        Patient p = patientDAO.getPatientById(id);
        if (p == null) { System.out.println("  Patient not found."); return; }
        System.out.printf("  Current: %s%n", p);
        System.out.print("New Name (blank=keep): "); String v = sc.nextLine().trim();
        if (!v.isEmpty()) p.setName(v);
        int age = readInt("New Age  (0=keep): ");
        if (age > 0) p.setAge(age);
        System.out.print("New Phone (blank=keep): "); v = sc.nextLine().trim();
        if (!v.isEmpty()) p.setPhone(v);
        System.out.print("New Address (blank=keep): "); v = sc.nextLine().trim();
        if (!v.isEmpty()) p.setAddress(v);
        System.out.println(patientDAO.updatePatient(p) ? "  ✓ Updated." : "  ✗ Update failed.");
    }

    private static void deletePatient() {
        int id = readInt("Patient ID to delete: ");
        System.out.print("Confirm delete? (yes/no): ");
        if ("yes".equalsIgnoreCase(sc.nextLine().trim()))
            System.out.println(patientDAO.deletePatient(id) ? "  ✓ Deleted." : "  ✗ Failed.");
        else
            System.out.println("  Cancelled.");
    }

    // ─────────────────────── DOCTORS ───────────────────────
    private static void doctorMenu() {
        while (true) {
            printSectionHeader("DOCTOR MANAGEMENT");
            System.out.println("  1. Add Doctor");
            System.out.println("  2. View All Doctors");
            System.out.println("  3. View Available Doctors");
            System.out.println("  4. Search by Specialization");
            System.out.println("  5. Toggle Availability");
            System.out.println("  0. Back");
            int ch = readInt("Choice: ");
            switch (ch) {
                case 1 -> addDoctor();
                case 2 -> listDoctors(doctorDAO.getAllDoctors());
                case 3 -> listDoctors(doctorDAO.getAvailableDoctors());
                case 4 -> { System.out.print("Specialization: "); listDoctors(doctorDAO.searchBySpecialization(sc.nextLine().trim())); }
                case 5 -> toggleDoctorAvailability();
                case 0 -> { return; }
                default -> System.out.println("  Invalid option.");
            }
        }
    }

    private static void addDoctor() {
        System.out.println("\n--- Add Doctor ---");
        Doctor d = new Doctor();
        System.out.print("Name           : "); d.setName(sc.nextLine().trim());
        System.out.print("Specialization : "); d.setSpecialization(sc.nextLine().trim());
        System.out.print("Phone          : "); d.setPhone(sc.nextLine().trim());
        System.out.print("Email          : "); d.setEmail(sc.nextLine().trim());
        d.setAvailable(true);
        System.out.println(doctorDAO.addDoctor(d) ? "  ✓ Doctor added. ID=" + d.getDoctorId() : "  ✗ Failed.");
    }

    private static void listDoctors(List<Doctor> list) {
        printTable("DOCTORS (" + list.size() + ")",
                "ID    | Name                      | Specialization       | Phone        | Status", list);
    }

    private static void toggleDoctorAvailability() {
        int id = readInt("Doctor ID: ");
        Doctor d = doctorDAO.getDoctorById(id);
        if (d == null) { System.out.println("  Doctor not found."); return; }
        d.setAvailable(!d.isAvailable());
        System.out.println(doctorDAO.updateDoctor(d)
                ? "  ✓ Availability set to: " + (d.isAvailable() ? "Available" : "Unavailable")
                : "  ✗ Failed.");
    }

    // ─────────────────────── APPOINTMENTS ───────────────────────
    private static void appointmentMenu() {
        while (true) {
            printSectionHeader("APPOINTMENT MANAGEMENT");
            System.out.println("  1. Book Appointment");
            System.out.println("  2. View All Appointments");
            System.out.println("  3. View Today's Appointments");
            System.out.println("  4. View by Patient ID");
            System.out.println("  5. Complete Appointment");
            System.out.println("  6. Cancel Appointment");
            System.out.println("  0. Back");
            int ch = readInt("Choice: ");
            switch (ch) {
                case 1 -> bookAppointment();
                case 2 -> listAppointments(appointmentDAO.getAllAppointments());
                case 3 -> listAppointments(appointmentDAO.getAppointmentsByDate(LocalDate.now()));
                case 4 -> { int pid = readInt("Patient ID: "); listAppointments(appointmentDAO.getAppointmentsByPatient(pid)); }
                case 5 -> appointmentDAO.updateStatus(readInt("Appointment ID: "), "COMPLETED");
                case 6 -> appointmentDAO.cancelAppointment(readInt("Appointment ID: "));
                case 0 -> { return; }
                default -> System.out.println("  Invalid option.");
            }
        }
    }

    private static void bookAppointment() {
        System.out.println("\n--- Book Appointment ---");
        int pid = readInt("Patient ID  : ");
        if (patientDAO.getPatientById(pid) == null) { System.out.println("  Patient not found."); return; }

        listDoctors(doctorDAO.getAvailableDoctors());
        int did = readInt("Doctor ID   : ");
        if (doctorDAO.getDoctorById(did) == null) { System.out.println("  Doctor not found."); return; }

        System.out.print("Date (YYYY-MM-DD): "); LocalDate date = LocalDate.parse(sc.nextLine().trim());
        System.out.print("Time (HH:MM)     : "); LocalTime time = LocalTime.parse(sc.nextLine().trim());
        System.out.print("Notes            : "); String notes = sc.nextLine().trim();

        Appointment appt = new Appointment(pid, did, date, time, notes);
        System.out.println(appointmentDAO.bookAppointment(appt)
                ? "  ✓ Appointment booked. ID=" + appt.getAppointmentId()
                : "  ✗ Booking failed.");
    }

    private static void listAppointments(List<Appointment> list) {
        printTable("APPOINTMENTS (" + list.size() + ")",
                "ID    | Patient              | Doctor               | Date         | Time     | Status", list);
    }

    // ─────────────────────── ROOMS ───────────────────────
    private static void roomMenu() {
        while (true) {
            printSectionHeader("ROOM MANAGEMENT");
            System.out.println("  1. Add Room");
            System.out.println("  2. View All Rooms");
            System.out.println("  3. View Available Rooms");
            System.out.println("  4. Update Room Status");
            System.out.println("  0. Back");
            int ch = readInt("Choice: ");
            switch (ch) {
                case 1 -> addRoom();
                case 2 -> listRooms(roomDAO.getAllRooms());
                case 3 -> listRooms(roomDAO.getAvailableRooms());
                case 4 -> {
                    int rid = readInt("Room ID: ");
                    System.out.print("Status (AVAILABLE/OCCUPIED/MAINTENANCE): ");
                    String s = sc.nextLine().trim().toUpperCase();
                    System.out.println(roomDAO.updateRoomStatus(rid, s) ? "  ✓ Updated." : "  ✗ Failed.");
                }
                case 0 -> { return; }
                default -> System.out.println("  Invalid option.");
            }
        }
    }

    private static void addRoom() {
        System.out.println("\n--- Add Room ---");
        Room r = new Room();
        System.out.print("Room Number              : "); r.setRoomNumber(sc.nextLine().trim());
        System.out.print("Type (GENERAL/PRIVATE/ICU/EMERGENCY): "); r.setRoomType(sc.nextLine().trim().toUpperCase());
        r.setPricePerDay(new BigDecimal(readDouble("Price per day (₹)       : ")));
        r.setStatus("AVAILABLE");
        System.out.println(roomDAO.addRoom(r) ? "  ✓ Room added. ID=" + r.getRoomId() : "  ✗ Failed.");
    }

    private static void listRooms(List<Room> list) {
        printTable("ROOMS (" + list.size() + ")",
                "ID    | Room   | Type       | Status       | Price/Day", list);
    }

    // ─────────────────────── ADMISSIONS ───────────────────────
    private static void admissionMenu() {
        while (true) {
            printSectionHeader("ADMISSION MANAGEMENT");
            System.out.println("  1. Admit Patient");
            System.out.println("  2. Current Admissions");
            System.out.println("  3. All Admissions");
            System.out.println("  4. Discharge Patient");
            System.out.println("  0. Back");
            int ch = readInt("Choice: ");
            switch (ch) {
                case 1 -> admitPatient();
                case 2 -> listAdmissions(admissionDAO.getCurrentAdmissions());
                case 3 -> listAdmissions(admissionDAO.getAllAdmissions());
                case 4 -> dischargePatient();
                case 0 -> { return; }
                default -> System.out.println("  Invalid option.");
            }
        }
    }

    private static void admitPatient() {
        System.out.println("\n--- Admit Patient ---");
        int pid = readInt("Patient ID  : ");
        if (patientDAO.getPatientById(pid) == null) { System.out.println("  Patient not found."); return; }

        listRooms(roomDAO.getAvailableRooms());
        int rid = readInt("Room ID     : ");
        Room room = roomDAO.getRoomById(rid);
        if (room == null || !"AVAILABLE".equals(room.getStatus())) { System.out.println("  Room not available."); return; }

        listDoctors(doctorDAO.getAvailableDoctors());
        int did = readInt("Doctor ID   : ");

        System.out.print("Diagnosis   : "); String diag = sc.nextLine().trim();

        Admission a = new Admission();
        a.setPatientId(pid);
        a.setRoomId(rid);
        a.setDoctorId(did);
        a.setAdmissionDate(LocalDate.now());
        a.setDiagnosis(diag);

        System.out.println(admissionDAO.admitPatient(a)
                ? "  ✓ Patient admitted. Admission ID=" + a.getAdmissionId()
                : "  ✗ Admission failed.");
    }

    private static void dischargePatient() {
        int aid = readInt("Admission ID: ");
        Admission a = admissionDAO.getAdmissionById(aid);
        if (a == null) { System.out.println("  Admission not found."); return; }
        System.out.printf("  Patient: %s | Room: %s | Admitted: %s%n", a.getPatientName(), a.getRoomNumber(), a.getAdmissionDate());

        // Calculate bill
        long days = LocalDate.now().toEpochDay() - a.getAdmissionDate().toEpochDay();
        if (days == 0) days = 1;
        Room room = roomDAO.getRoomById(a.getRoomId());
        BigDecimal roomBill = room.getPricePerDay().multiply(BigDecimal.valueOf(days));
        System.out.printf("  Days: %d | Room rate: ₹%.2f | Room charges: ₹%.2f%n", days, room.getPricePerDay(), roomBill);
        System.out.print("  Additional charges (₹): ");
        BigDecimal extra = new BigDecimal(sc.nextLine().trim());
        BigDecimal total = roomBill.add(extra);
        System.out.printf("  Total bill: ₹%.2f%n", total);

        boolean ok = admissionDAO.dischargePatient(aid, LocalDate.now(), total);
        if (ok) {
            System.out.println("  ✓ Patient discharged.");
            // Auto-generate bill
            Bill bill = new Bill();
            bill.setPatientId(a.getPatientId());
            bill.setAdmissionId(aid);
            bill.setTotalAmount(total);
            bill.setPaidAmount(BigDecimal.ZERO);
            bill.setPaymentStatus("PENDING");
            bill.setBillDate(LocalDate.now());
            billDAO.generateBill(bill);
            System.out.println("  ✓ Bill generated. Bill ID=" + bill.getBillId());
        }
    }

    private static void listAdmissions(List<Admission> list) {
        printTable("ADMISSIONS (" + list.size() + ")",
                "ID    | Patient              | Room   | Doctor       | Admitted     | Status", list);
    }

    // ─────────────────────── MEDICINES ───────────────────────
    private static void medicineMenu() {
        while (true) {
            printSectionHeader("MEDICINE / PHARMACY");
            System.out.println("  1. Add Medicine");
            System.out.println("  2. View All Medicines");
            System.out.println("  3. Search Medicine");
            System.out.println("  4. Update Stock");
            System.out.println("  5. Low Stock Alert (≤50)");
            System.out.println("  6. Delete Medicine");
            System.out.println("  0. Back");
            int ch = readInt("Choice: ");
            switch (ch) {
                case 1 -> addMedicine();
                case 2 -> listMedicines(medicineDAO.getAllMedicines());
                case 3 -> { System.out.print("Search: "); listMedicines(medicineDAO.searchMedicines(sc.nextLine().trim())); }
                case 4 -> { int id = readInt("Medicine ID: "); int qty = readInt("New quantity: "); System.out.println(medicineDAO.updateStock(id, qty) ? "  ✓ Updated." : "  ✗ Failed."); }
                case 5 -> listMedicines(medicineDAO.getLowStockMedicines(50));
                case 6 -> { System.out.println(medicineDAO.deleteMedicine(readInt("Medicine ID: ")) ? "  ✓ Deleted." : "  ✗ Failed."); }
                case 0 -> { return; }
                default -> System.out.println("  Invalid option.");
            }
        }
    }

    private static void addMedicine() {
        System.out.println("\n--- Add Medicine ---");
        Medicine m = new Medicine();
        System.out.print("Name         : "); m.setName(sc.nextLine().trim());
        System.out.print("Manufacturer : "); m.setManufacturer(sc.nextLine().trim());
        m.setQuantity(readInt("Quantity     : "));
        m.setPrice(new BigDecimal(readDouble("Price (₹)    : ")));
        System.out.print("Expiry (YYYY-MM-DD): "); m.setExpiryDate(LocalDate.parse(sc.nextLine().trim()));
        System.out.println(medicineDAO.addMedicine(m) ? "  ✓ Medicine added. ID=" + m.getMedicineId() : "  ✗ Failed.");
    }

    private static void listMedicines(List<Medicine> list) {
        printTable("MEDICINES (" + list.size() + ")",
                "ID    | Name                      | Manufacturer    | Qty   | Price    | Expiry", list);
    }

    // ─────────────────────── BILLING ───────────────────────
    private static void billingMenu() {
        while (true) {
            printSectionHeader("BILLING");
            System.out.println("  1. View All Bills");
            System.out.println("  2. Pending Bills");
            System.out.println("  3. Make Payment");
            System.out.println("  4. Generate Manual Bill");
            System.out.println("  0. Back");
            int ch = readInt("Choice: ");
            switch (ch) {
                case 1 -> listBills(billDAO.getAllBills());
                case 2 -> listBills(billDAO.getPendingBills());
                case 3 -> makePayment();
                case 4 -> generateManualBill();
                case 0 -> { return; }
                default -> System.out.println("  Invalid option.");
            }
        }
    }

    private static void listBills(List<Bill> list) {
        printTable("BILLS (" + list.size() + ")",
                "BillID | Patient              | Total        | Paid         | Due          | Status", list);
    }

    private static void makePayment() {
        int bid = readInt("Bill ID : ");
        Bill b = billDAO.getBillById(bid);
        if (b == null) { System.out.println("  Bill not found."); return; }
        System.out.println("  " + b);
        BigDecimal due = b.getTotalAmount().subtract(b.getPaidAmount());
        System.out.printf("  Outstanding: ₹%.2f%n", due);
        BigDecimal pay = new BigDecimal(readDouble("Payment amount (₹): "));
        System.out.println(billDAO.makePayment(bid, pay) ? "  ✓ Payment recorded." : "  ✗ Failed.");
    }

    private static void generateManualBill() {
        System.out.println("\n--- Generate Bill ---");
        int pid = readInt("Patient ID    : ");
        if (patientDAO.getPatientById(pid) == null) { System.out.println("  Patient not found."); return; }
        BigDecimal total = new BigDecimal(readDouble("Total Amount  : "));
        Bill bill = new Bill();
        bill.setPatientId(pid);
        bill.setTotalAmount(total);
        bill.setPaidAmount(BigDecimal.ZERO);
        bill.setPaymentStatus("PENDING");
        bill.setBillDate(LocalDate.now());
        System.out.println(billDAO.generateBill(bill) ? "  ✓ Bill generated. ID=" + bill.getBillId() : "  ✗ Failed.");
    }

    // ─────────────────────── REPORTS ───────────────────────
    private static void reportsMenu() {
        while (true) {
            printSectionHeader("REPORTS & DASHBOARD");
            System.out.println("  1. Hospital Summary");
            System.out.println("  2. Today's Appointments");
            System.out.println("  3. Current Admissions");
            System.out.println("  4. Pending Bills");
            System.out.println("  5. Low Stock Medicines");
            System.out.println("  0. Back");
            int ch = readInt("Choice: ");
            switch (ch) {
                case 1 -> printDashboard();
                case 2 -> listAppointments(appointmentDAO.getAppointmentsByDate(LocalDate.now()));
                case 3 -> listAdmissions(admissionDAO.getCurrentAdmissions());
                case 4 -> listBills(billDAO.getPendingBills());
                case 5 -> listMedicines(medicineDAO.getLowStockMedicines(50));
                case 0 -> { return; }
                default -> System.out.println("  Invalid option.");
            }
        }
    }

    private static void printDashboard() {
        System.out.println("\n╔══════════════════════════════════════╗");
        System.out.println("║         HOSPITAL DASHBOARD           ║");
        System.out.println("╚══════════════════════════════════════╝");
        System.out.printf("  Total Patients      : %d%n", patientDAO.getAllPatients().size());
        System.out.printf("  Total Doctors       : %d%n", doctorDAO.getAllDoctors().size());
        System.out.printf("  Available Doctors   : %d%n", doctorDAO.getAvailableDoctors().size());
        System.out.printf("  Total Rooms         : %d%n", roomDAO.getAllRooms().size());
        System.out.printf("  Available Rooms     : %d%n", roomDAO.getAvailableRooms().size());
        System.out.printf("  Current Admissions  : %d%n", admissionDAO.getCurrentAdmissions().size());
        System.out.printf("  Today's Appointments: %d%n", appointmentDAO.getAppointmentsByDate(LocalDate.now()).size());
        System.out.printf("  Pending Bills       : %d%n", billDAO.getPendingBills().size());
        List<Medicine> low = medicineDAO.getLowStockMedicines(50);
        System.out.printf("  Low Stock Medicines : %d%n", low.size());
        if (!low.isEmpty()) {
            System.out.println("  ⚠ Low stock: ");
            low.forEach(m -> System.out.printf("      - %s (qty: %d)%n", m.getName(), m.getQuantity()));
        }
        System.out.println();
    }

    // ─────────────────────── HELPERS ───────────────────────
    private static void printBanner() {
        System.out.println("""
            ╔═══════════════════════════════════════════════════╗
            ║       HOSPITAL MANAGEMENT SYSTEM  v1.0           ║
            ║              Powered by Java + JDBC              ║
            ╚═══════════════════════════════════════════════════╝
            """);
    }

    private static void printMainMenu() {
        System.out.println("\n╔══════════════════════════════╗");
        System.out.println("║         MAIN MENU            ║");
        System.out.println("╠══════════════════════════════╣");
        System.out.println("║  1. Patient Management       ║");
        System.out.println("║  2. Doctor Management        ║");
        System.out.println("║  3. Appointments             ║");
        System.out.println("║  4. Room Management          ║");
        System.out.println("║  5. Admissions               ║");
        System.out.println("║  6. Medicine / Pharmacy      ║");
        System.out.println("║  7. Billing                  ║");
        System.out.println("║  8. Reports & Dashboard      ║");
        System.out.println("║  0. Exit                     ║");
        System.out.println("╚══════════════════════════════╝");
    }

    private static void printSectionHeader(String title) {
        System.out.println("\n┌─────────────────────────────────────┐");
        System.out.printf( "│  %-35s│%n", title);
        System.out.println("└─────────────────────────────────────┘");
    }

    private static <T> void printTable(String title, String header, List<T> list) {
        System.out.println("\n  ─── " + title + " ───");
        System.out.println("  " + header);
        System.out.println("  " + "─".repeat(header.length()));
        if (list.isEmpty()) {
            System.out.println("  (No records found)");
        } else {
            list.forEach(item -> System.out.println("  " + item));
        }
        System.out.println("  " + "─".repeat(header.length()));
    }

    private static int readInt(String prompt) {
        while (true) {
            System.out.print(prompt);
            String line = sc.nextLine().trim();
            try { return Integer.parseInt(line); }
            catch (NumberFormatException e) { System.out.println("  Please enter a valid number."); }
        }
    }

    private static double readDouble(String prompt) {
        while (true) {
            System.out.print(prompt);
            String line = sc.nextLine().trim();
            try { return Double.parseDouble(line); }
            catch (NumberFormatException e) { System.out.println("  Please enter a valid number."); }
        }
    }
}
