package com.hospital.util;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * Run this once to create all required tables in the hospital_db database.
 * Usage: compile and run DatabaseSetup.main()
 */
public class DatabaseSetup {

    public static void initializeDatabase() {
        String createDB = "CREATE DATABASE IF NOT EXISTS hospital_db";

        String patients = """
            CREATE TABLE IF NOT EXISTS patients (
                patient_id    INT AUTO_INCREMENT PRIMARY KEY,
                name          VARCHAR(100) NOT NULL,
                age           INT NOT NULL,
                gender        VARCHAR(10) NOT NULL,
                phone         VARCHAR(15),
                address       TEXT,
                blood_group   VARCHAR(5),
                created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
            """;

        String doctors = """
            CREATE TABLE IF NOT EXISTS doctors (
                doctor_id     INT AUTO_INCREMENT PRIMARY KEY,
                name          VARCHAR(100) NOT NULL,
                specialization VARCHAR(100) NOT NULL,
                phone         VARCHAR(15),
                email         VARCHAR(100),
                available     BOOLEAN DEFAULT TRUE,
                created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
            """;

        String appointments = """
            CREATE TABLE IF NOT EXISTS appointments (
                appointment_id INT AUTO_INCREMENT PRIMARY KEY,
                patient_id     INT NOT NULL,
                doctor_id      INT NOT NULL,
                appointment_date DATE NOT NULL,
                appointment_time TIME NOT NULL,
                status         ENUM('SCHEDULED','COMPLETED','CANCELLED') DEFAULT 'SCHEDULED',
                notes          TEXT,
                created_at     TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (patient_id) REFERENCES patients(patient_id) ON DELETE CASCADE,
                FOREIGN KEY (doctor_id)  REFERENCES doctors(doctor_id)  ON DELETE CASCADE
            )
            """;

        String rooms = """
            CREATE TABLE IF NOT EXISTS rooms (
                room_id       INT AUTO_INCREMENT PRIMARY KEY,
                room_number   VARCHAR(10) NOT NULL UNIQUE,
                room_type     ENUM('GENERAL','PRIVATE','ICU','EMERGENCY') NOT NULL,
                status        ENUM('AVAILABLE','OCCUPIED','MAINTENANCE') DEFAULT 'AVAILABLE',
                price_per_day DECIMAL(10,2) NOT NULL
            )
            """;

        String admissions = """
            CREATE TABLE IF NOT EXISTS admissions (
                admission_id   INT AUTO_INCREMENT PRIMARY KEY,
                patient_id     INT NOT NULL,
                room_id        INT NOT NULL,
                doctor_id      INT NOT NULL,
                admission_date DATE NOT NULL,
                discharge_date DATE,
                diagnosis      TEXT,
                total_bill     DECIMAL(10,2),
                status         ENUM('ADMITTED','DISCHARGED') DEFAULT 'ADMITTED',
                FOREIGN KEY (patient_id) REFERENCES patients(patient_id) ON DELETE CASCADE,
                FOREIGN KEY (room_id)    REFERENCES rooms(room_id),
                FOREIGN KEY (doctor_id)  REFERENCES doctors(doctor_id)
            )
            """;

        String medicines = """
            CREATE TABLE IF NOT EXISTS medicines (
                medicine_id   INT AUTO_INCREMENT PRIMARY KEY,
                name          VARCHAR(100) NOT NULL,
                manufacturer  VARCHAR(100),
                quantity      INT NOT NULL DEFAULT 0,
                price         DECIMAL(10,2) NOT NULL,
                expiry_date   DATE
            )
            """;

        String prescriptions = """
            CREATE TABLE IF NOT EXISTS prescriptions (
                prescription_id INT AUTO_INCREMENT PRIMARY KEY,
                appointment_id  INT NOT NULL,
                medicine_id     INT NOT NULL,
                dosage          VARCHAR(100),
                duration_days   INT,
                FOREIGN KEY (appointment_id) REFERENCES appointments(appointment_id) ON DELETE CASCADE,
                FOREIGN KEY (medicine_id)    REFERENCES medicines(medicine_id)
            )
            """;

        String bills = """
            CREATE TABLE IF NOT EXISTS bills (
                bill_id        INT AUTO_INCREMENT PRIMARY KEY,
                patient_id     INT NOT NULL,
                admission_id   INT,
                total_amount   DECIMAL(10,2) NOT NULL,
                paid_amount    DECIMAL(10,2) DEFAULT 0,
                payment_status ENUM('PENDING','PARTIAL','PAID') DEFAULT 'PENDING',
                bill_date      DATE NOT NULL,
                FOREIGN KEY (patient_id)   REFERENCES patients(patient_id),
                FOREIGN KEY (admission_id) REFERENCES admissions(admission_id)
            )
            """;

        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement()) {

            stmt.executeUpdate(createDB);
            stmt.executeUpdate("USE hospital_db");
            stmt.executeUpdate(patients);
            stmt.executeUpdate(doctors);
            stmt.executeUpdate(appointments);
            stmt.executeUpdate(rooms);
            stmt.executeUpdate(admissions);
            stmt.executeUpdate(medicines);
            stmt.executeUpdate(prescriptions);
            stmt.executeUpdate(bills);

            System.out.println("✓ All tables created successfully.");
            seedSampleData(stmt);

        } catch (SQLException e) {
            System.err.println("Database setup failed: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private static void seedSampleData(Statement stmt) throws SQLException {
        // Sample doctors
        stmt.executeUpdate("""
            INSERT IGNORE INTO doctors (name, specialization, phone, email) VALUES
            ('Dr. Anil Sharma',   'Cardiologist',   '9876543210', 'anil@hospital.com'),
            ('Dr. Priya Mehta',   'Neurologist',    '9876543211', 'priya@hospital.com'),
            ('Dr. Rajan Patel',   'Orthopedician',  '9876543212', 'rajan@hospital.com'),
            ('Dr. Sunita Gupta',  'Pediatrician',   '9876543213', 'sunita@hospital.com'),
            ('Dr. Vikas Kumar',   'General Surgery','9876543214', 'vikas@hospital.com')
            """);

        // Sample rooms
        stmt.executeUpdate("""
            INSERT IGNORE INTO rooms (room_number, room_type, price_per_day) VALUES
            ('G101','GENERAL',  800.00),
            ('G102','GENERAL',  800.00),
            ('P201','PRIVATE', 2000.00),
            ('P202','PRIVATE', 2000.00),
            ('I301','ICU',     5000.00),
            ('E401','EMERGENCY',3000.00)
            """);

        // Sample medicines
        stmt.executeUpdate("""
            INSERT IGNORE INTO medicines (name, manufacturer, quantity, price, expiry_date) VALUES
            ('Paracetamol 500mg',  'Sun Pharma',   500, 2.50,  '2026-12-31'),
            ('Amoxicillin 250mg',  'Cipla',        300, 8.00,  '2026-06-30'),
            ('Metformin 500mg',    'Dr. Reddy',    400, 5.00,  '2027-03-31'),
            ('Atorvastatin 20mg',  'Ranbaxy',      200, 15.00, '2026-09-30'),
            ('Omeprazole 20mg',    'Abbott',       350, 6.50,  '2027-01-31')
            """);

        System.out.println("✓ Sample data seeded.");
    }

    public static void main(String[] args) {
        initializeDatabase();
        DBConnection.closeConnection();
    }
}
