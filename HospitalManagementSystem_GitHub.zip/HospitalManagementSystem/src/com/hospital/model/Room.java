package com.hospital.model;

import java.math.BigDecimal;

public class Room {
    private int roomId;
    private String roomNumber;
    private String roomType;   // GENERAL, PRIVATE, ICU, EMERGENCY
    private String status;     // AVAILABLE, OCCUPIED, MAINTENANCE
    private BigDecimal pricePerDay;

    public Room() {}

    public Room(String roomNumber, String roomType, BigDecimal pricePerDay) {
        this.roomNumber = roomNumber;
        this.roomType = roomType;
        this.pricePerDay = pricePerDay;
        this.status = "AVAILABLE";
    }

    public int getRoomId()                       { return roomId; }
    public void setRoomId(int id)                { this.roomId = id; }
    public String getRoomNumber()                { return roomNumber; }
    public void setRoomNumber(String n)          { this.roomNumber = n; }
    public String getRoomType()                  { return roomType; }
    public void setRoomType(String t)            { this.roomType = t; }
    public String getStatus()                    { return status; }
    public void setStatus(String s)              { this.status = s; }
    public BigDecimal getPricePerDay()           { return pricePerDay; }
    public void setPricePerDay(BigDecimal price) { this.pricePerDay = price; }

    @Override
    public String toString() {
        return String.format("ID:%-4d | Room:%-6s | %-10s | %-12s | ₹%.2f/day",
                roomId, roomNumber, roomType, status, pricePerDay);
    }
}
