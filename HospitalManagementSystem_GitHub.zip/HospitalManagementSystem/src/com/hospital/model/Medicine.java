package com.hospital.model;

import java.math.BigDecimal;
import java.time.LocalDate;

public class Medicine {
    private int medicineId;
    private String name;
    private String manufacturer;
    private int quantity;
    private BigDecimal price;
    private LocalDate expiryDate;

    public Medicine() {}

    public Medicine(String name, String manufacturer, int quantity, BigDecimal price, LocalDate expiryDate) {
        this.name = name;
        this.manufacturer = manufacturer;
        this.quantity = quantity;
        this.price = price;
        this.expiryDate = expiryDate;
    }

    public int getMedicineId()                   { return medicineId; }
    public void setMedicineId(int id)            { this.medicineId = id; }
    public String getName()                      { return name; }
    public void setName(String n)                { this.name = n; }
    public String getManufacturer()              { return manufacturer; }
    public void setManufacturer(String m)        { this.manufacturer = m; }
    public int getQuantity()                     { return quantity; }
    public void setQuantity(int q)               { this.quantity = q; }
    public BigDecimal getPrice()                 { return price; }
    public void setPrice(BigDecimal p)           { this.price = p; }
    public LocalDate getExpiryDate()             { return expiryDate; }
    public void setExpiryDate(LocalDate d)       { this.expiryDate = d; }

    @Override
    public String toString() {
        return String.format("ID:%-4d | %-25s | %-15s | Qty:%-5d | ₹%-8.2f | Exp:%s",
                medicineId, name, manufacturer, quantity, price, expiryDate);
    }
}
