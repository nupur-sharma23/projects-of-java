package com.hospital.model;

import java.math.BigDecimal;
import java.time.LocalDate;

public class Admission {
    private int admissionId;
    private int patientId;
    private int roomId;
    private int doctorId;
    private LocalDate admissionDate;
    private LocalDate dischargeDate;
    private String diagnosis;
    private BigDecimal totalBill;
    private String status; // ADMITTED, DISCHARGED
    // Display fields
    private String patientName;
    private String roomNumber;
    private String doctorName;

    public Admission() {}

    public int getAdmissionId()                  { return admissionId; }
    public void setAdmissionId(int id)           { this.admissionId = id; }
    public int getPatientId()                    { return patientId; }
    public void setPatientId(int id)             { this.patientId = id; }
    public int getRoomId()                       { return roomId; }
    public void setRoomId(int id)                { this.roomId = id; }
    public int getDoctorId()                     { return doctorId; }
    public void setDoctorId(int id)              { this.doctorId = id; }
    public LocalDate getAdmissionDate()          { return admissionDate; }
    public void setAdmissionDate(LocalDate d)    { this.admissionDate = d; }
    public LocalDate getDischargeDate()          { return dischargeDate; }
    public void setDischargeDate(LocalDate d)    { this.dischargeDate = d; }
    public String getDiagnosis()                 { return diagnosis; }
    public void setDiagnosis(String d)           { this.diagnosis = d; }
    public BigDecimal getTotalBill()             { return totalBill; }
    public void setTotalBill(BigDecimal b)       { this.totalBill = b; }
    public String getStatus()                    { return status; }
    public void setStatus(String s)              { this.status = s; }
    public String getPatientName()               { return patientName; }
    public void setPatientName(String n)         { this.patientName = n; }
    public String getRoomNumber()                { return roomNumber; }
    public void setRoomNumber(String n)          { this.roomNumber = n; }
    public String getDoctorName()                { return doctorName; }
    public void setDoctorName(String n)          { this.doctorName = n; }

    @Override
    public String toString() {
        return String.format("ID:%-4d | %-20s | Room:%-6s | %-12s | Admitted:%-12s | %s",
                admissionId, patientName, roomNumber, doctorName, admissionDate, status);
    }
}
