package com.hospital.model;

import java.math.BigDecimal;
import java.time.LocalDate;

public class Bill {
    private int billId;
    private int patientId;
    private Integer admissionId;
    private BigDecimal totalAmount;
    private BigDecimal paidAmount;
    private String paymentStatus; // PENDING, PARTIAL, PAID
    private LocalDate billDate;
    private String patientName;

    public Bill() {}

    public int getBillId()                        { return billId; }
    public void setBillId(int id)                 { this.billId = id; }
    public int getPatientId()                     { return patientId; }
    public void setPatientId(int id)              { this.patientId = id; }
    public Integer getAdmissionId()               { return admissionId; }
    public void setAdmissionId(Integer id)        { this.admissionId = id; }
    public BigDecimal getTotalAmount()            { return totalAmount; }
    public void setTotalAmount(BigDecimal a)      { this.totalAmount = a; }
    public BigDecimal getPaidAmount()             { return paidAmount; }
    public void setPaidAmount(BigDecimal a)       { this.paidAmount = a; }
    public String getPaymentStatus()              { return paymentStatus; }
    public void setPaymentStatus(String s)        { this.paymentStatus = s; }
    public LocalDate getBillDate()                { return billDate; }
    public void setBillDate(LocalDate d)          { this.billDate = d; }
    public String getPatientName()                { return patientName; }
    public void setPatientName(String n)          { this.patientName = n; }

    @Override
    public String toString() {
        BigDecimal due = totalAmount.subtract(paidAmount);
        return String.format("BillID:%-4d | %-20s | Total:₹%-10.2f | Paid:₹%-10.2f | Due:₹%-10.2f | %s",
                billId, patientName, totalAmount, paidAmount, due, paymentStatus);
    }
}
