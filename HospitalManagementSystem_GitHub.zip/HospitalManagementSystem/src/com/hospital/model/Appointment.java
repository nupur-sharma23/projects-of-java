package com.hospital.model;

import java.time.LocalDate;
import java.time.LocalTime;

public class Appointment {
    private int appointmentId;
    private int patientId;
    private int doctorId;
    private LocalDate appointmentDate;
    private LocalTime appointmentTime;
    private String status; // SCHEDULED, COMPLETED, CANCELLED
    private String notes;
    // For display
    private String patientName;
    private String doctorName;

    public Appointment() {}

    public Appointment(int patientId, int doctorId, LocalDate date, LocalTime time, String notes) {
        this.patientId = patientId;
        this.doctorId = doctorId;
        this.appointmentDate = date;
        this.appointmentTime = time;
        this.notes = notes;
        this.status = "SCHEDULED";
    }

    public int getAppointmentId()               { return appointmentId; }
    public void setAppointmentId(int id)        { this.appointmentId = id; }
    public int getPatientId()                   { return patientId; }
    public void setPatientId(int id)            { this.patientId = id; }
    public int getDoctorId()                    { return doctorId; }
    public void setDoctorId(int id)             { this.doctorId = id; }
    public LocalDate getAppointmentDate()       { return appointmentDate; }
    public void setAppointmentDate(LocalDate d) { this.appointmentDate = d; }
    public LocalTime getAppointmentTime()       { return appointmentTime; }
    public void setAppointmentTime(LocalTime t) { this.appointmentTime = t; }
    public String getStatus()                   { return status; }
    public void setStatus(String s)             { this.status = s; }
    public String getNotes()                    { return notes; }
    public void setNotes(String n)              { this.notes = n; }
    public String getPatientName()              { return patientName; }
    public void setPatientName(String n)        { this.patientName = n; }
    public String getDoctorName()               { return doctorName; }
    public void setDoctorName(String n)         { this.doctorName = n; }

    @Override
    public String toString() {
        return String.format("ID:%-4d | %-20s | %-20s | %-12s | %-8s | %-12s",
                appointmentId, patientName, doctorName, appointmentDate, appointmentTime, status);
    }
}
