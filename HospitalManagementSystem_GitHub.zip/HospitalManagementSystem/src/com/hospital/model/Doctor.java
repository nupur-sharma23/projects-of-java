package com.hospital.model;

public class Doctor {
    private int doctorId;
    private String name;
    private String specialization;
    private String phone;
    private String email;
    private boolean available;

    public Doctor() {}

    public Doctor(String name, String specialization, String phone, String email) {
        this.name = name;
        this.specialization = specialization;
        this.phone = phone;
        this.email = email;
        this.available = true;
    }

    public int getDoctorId()                { return doctorId; }
    public void setDoctorId(int id)         { this.doctorId = id; }
    public String getName()                 { return name; }
    public void setName(String n)           { this.name = n; }
    public String getSpecialization()       { return specialization; }
    public void setSpecialization(String s) { this.specialization = s; }
    public String getPhone()                { return phone; }
    public void setPhone(String p)          { this.phone = p; }
    public String getEmail()                { return email; }
    public void setEmail(String e)          { this.email = e; }
    public boolean isAvailable()            { return available; }
    public void setAvailable(boolean a)     { this.available = a; }

    @Override
    public String toString() {
        return String.format("ID:%-4d | %-25s | %-20s | %-12s | %s",
                doctorId, name, specialization, phone, available ? "Available" : "Unavailable");
    }
}
