package com.hospital.model;

import java.time.LocalDateTime;

public class Patient {
    private int patientId;
    private String name;
    private int age;
    private String gender;
    private String phone;
    private String address;
    private String bloodGroup;
    private LocalDateTime createdAt;

    public Patient() {}

    public Patient(String name, int age, String gender, String phone, String address, String bloodGroup) {
        this.name = name;
        this.age = age;
        this.gender = gender;
        this.phone = phone;
        this.address = address;
        this.bloodGroup = bloodGroup;
    }

    // Getters & Setters
    public int getPatientId()               { return patientId; }
    public void setPatientId(int id)        { this.patientId = id; }
    public String getName()                 { return name; }
    public void setName(String name)        { this.name = name; }
    public int getAge()                     { return age; }
    public void setAge(int age)             { this.age = age; }
    public String getGender()               { return gender; }
    public void setGender(String g)         { this.gender = g; }
    public String getPhone()                { return phone; }
    public void setPhone(String p)          { this.phone = p; }
    public String getAddress()              { return address; }
    public void setAddress(String a)        { this.address = a; }
    public String getBloodGroup()           { return bloodGroup; }
    public void setBloodGroup(String bg)    { this.bloodGroup = bg; }
    public LocalDateTime getCreatedAt()     { return createdAt; }
    public void setCreatedAt(LocalDateTime t){ this.createdAt = t; }

    @Override
    public String toString() {
        return String.format("ID:%-4d | %-25s | Age:%-3d | %-6s | %-12s | %-5s",
                patientId, name, age, gender, phone, bloodGroup);
    }
}
