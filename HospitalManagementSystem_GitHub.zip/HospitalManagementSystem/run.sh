#!/bin/bash
# ─────────────────────────────────────────────────────────────
#  Hospital Management System - Build & Run Script
#  Requirements: Java 17+, MySQL 8+, mysql-connector-java jar
# ─────────────────────────────────────────────────────────────

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
SRC_DIR="$SCRIPT_DIR/src"
OUT_DIR="$SCRIPT_DIR/out"
LIB_DIR="$SCRIPT_DIR/lib"
JAR="$LIB_DIR/mysql-connector-j-8.0.33.jar"

# 1. Download MySQL connector if not present
if [ ! -f "$JAR" ]; then
    mkdir -p "$LIB_DIR"
    echo "Downloading MySQL Connector/J..."
    curl -L "https://repo1.maven.org/maven2/com/mysql/mysql-connector-j/8.0.33/mysql-connector-j-8.0.33.jar" \
         -o "$JAR" --progress-bar
    echo "Done."
fi

# 2. Compile
echo "Compiling sources..."
mkdir -p "$OUT_DIR"
find "$SRC_DIR" -name "*.java" | xargs javac -cp "$JAR" -d "$OUT_DIR"
if [ $? -ne 0 ]; then echo "Compilation failed!"; exit 1; fi
echo "Compilation successful."

# 3. Run
echo "Starting Hospital Management System..."
java -cp "$OUT_DIR:$JAR" com.hospital.ui.MainMenu
